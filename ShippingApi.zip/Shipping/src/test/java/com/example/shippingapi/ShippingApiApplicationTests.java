package com.example.shippingapi;

import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.Assertions.assertTrue;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingApiApplicationTests {

    @Test
    void E(){
        assertTrue(ShippingController.Envelope(5, 5, 5, 5));
        assertFalse(ShippingController.Envelope(3,2,4,6));
    }


    @Test
    void S(){
        assertTrue(ShippingController.SmallBox(5, 5, 5, 5));
        assertFalse(ShippingController.SmallBox(20,30,23,4));
    }

    @Test
    L(){
        assertTrue(ShippingController.LargeBox(20, 5, 5, 5000));
        assertFalase(ShippingController.LargeBox(4,4,0.1,30));
    }
}
