package com.example.shippingapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ShippingController {

    @GetMapping("/shipping-info")
    public String grab(@RequestParam double height, @RequestParam double width, @RequestParam double length, @RequestParam double weight)
        throws IOException{

        String Box = "";
        String Price = "";

        if(Envelope(height, width, length, weight) == true){
            Box = "Envelope";
            Price = "0.50";
            return "{\n" + "shippingType: " + Box + "\nprice: " + Price + "\n}";
        }else if(SmallBox(height, width, length, weight) == true){
            Box = "Small Box";
            Price = "3.50";
            return "{\n" + "shippingType: " + Box + "\nprice: " + Price + "\n}";
        }else if(LargeBox(height, width, length, weight) == true){
            Box = "Large Box";
            double p = (length * width * height * 0.01) + (weight * 0.1);
            Price = Double.toString(p);
            return "{\n" + "shippingType: " + Box + "\nprice: " + Price + "\n}";
        }else{
            Box = "Box not found";
            Price = "Price not found";
        }

        return "{\n" + "\"shippingType\": " + Box + "\n\"price\": " + Price + "\n}";
    }


    public static boolean Envelope(double height, double width, double length, double weight){
        if(height <= 10 && width <= 10 && length <= 10 && weight <= 50){
            return true;
        }
        return false;
    }

    public static boolean SmallBox(double height, double width, double length, double weight){
        if(height <= 10 && width <= 10 && length <= 10 && weight >= 50 && weight <= 500){
            return true;
        }
        return false;
    }

    public static boolean LargeBox(double height, double width, double length, double weight){
        if(weight > 500 || height > 10 || width > 10 || length > 10){
            return true;
        }
        return false;

    }
}
